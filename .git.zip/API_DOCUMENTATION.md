# API Reference

> Base URL: `https://your-domain.com/api/v1`
>
> All responses follow: `{ success, data, message?, meta?, error?, code? }`

---

## Authentication

### Headers

| Header | Used By | Format |
|---|---|---|
| `Authorization` | JWT-protected routes | `Bearer <access_token>` |
| `X-API-Key` | API key routes | `sk_live_<key>` |

### Error Codes

| HTTP | Code | Meaning |
|---|---|---|
| 401 | `UNAUTHORIZED` | Missing/invalid token or API key |
| 403 | `FORBIDDEN` | Insufficient role |
| 404 | `NOT_FOUND` | Resource doesn't exist or belongs to another tenant |
| 409 | `CONFLICT` | Duplicate entry / invalid state transition |
| 422 | `VALIDATION_ERROR` | Request body/query failed schema validation |
| 500 | `INTERNAL_ERROR` | Server error |

---

## Auth Module

### `POST /auth/register`

Create a new tenant and owner account.

**Request Body**
```json
{
  "businessName": "Acme Corp",
  "email": "owner@acme.com",
  "password": "str0ngP@ss!",
  "displayName": "Jane Smith"
}
```

**Response `201`**
```json
{
  "success": true,
  "message": "Registration successful",
  "data": {
    "accessToken": "eyJ...",
    "refreshToken": "eyJ...",
    "tenant": { "id": 1, "name": "Acme Corp", "slug": "acme-corp-a1b2c3", "plan": "free" }
  }
}
```

**Errors:** `422` validation failed · `409` email already registered

---

### `POST /auth/login`

**Request Body**
```json
{ "email": "owner@acme.com", "password": "str0ngP@ss!" }
```

**Response `200`**
```json
{
  "success": true,
  "data": {
    "accessToken": "eyJ...",
    "refreshToken": "eyJ...",
    "expiresAt": 1743091200,
    "user": { "id": "uuid", "email": "owner@acme.com", "role": "owner", "tenantId": 1, "displayName": "Jane" },
    "tenant": { "id": 1, "name": "Acme Corp", "slug": "acme-corp-a1b2c3", "plan": "free" }
  }
}
```

---

### `POST /auth/refresh`

**Request Body**
```json
{ "refreshToken": "eyJ..." }
```

**Response `200`**
```json
{ "success": true, "data": { "accessToken": "eyJ...", "refreshToken": "eyJ...", "expiresAt": 1743177600 } }
```

---

### `GET /auth/me`

**Auth:** Bearer JWT

**Response `200`**
```json
{
  "success": true,
  "data": {
    "user": { "id": "uuid", "email": "owner@acme.com", "displayName": "Jane", "role": "owner", "isActive": true },
    "tenant": { "id": 1, "name": "Acme Corp", "slug": "acme-corp-a1b2c3", "plan": "free", "status": "active" }
  }
}
```

---

### `POST /auth/change-password`

**Auth:** Bearer JWT · **Body:** `{ "password": "newP@ss123" }`

**Response `200`** `{ "success": true, "message": "Password updated successfully" }`

---

### `POST /auth/logout`

**Auth:** Bearer JWT · **Response `200`** `{ "success": true, "message": "Logged out successfully" }`

---

## Contacts Module

> **Auth:** Bearer JWT · All contacts are strictly scoped to the authenticated tenant.

### `GET /contacts`

**Query Parameters**

| Param | Type | Description |
|---|---|---|
| `stage` | `new\|contacted\|qualified\|converted\|lost` | Filter by pipeline stage |
| `search` | string (max 100) | Search name or phone (case-insensitive) |
| `tag` | string | Filter to contacts with this tag |
| `cursor` | string | Pagination cursor from previous response |
| `limit` | integer 1–100 | Items per page (default: 50) |

**Response `200`**
```json
{
  "success": true,
  "data": [
    {
      "id": 101, "tenant_id": 1, "phone": "+15551234567",
      "name": "John Doe", "email": "john@doe.com",
      "stage": "qualified", "notes": null,
      "created_at": "2026-01-15T10:00:00Z",
      "last_active": "2026-03-20T14:30:00Z", "deleted_at": null
    }
  ],
  "meta": { "nextCursor": "eyJpZCI6MTAxLCJ0cyI6Ii4uLiJ9", "hasMore": true }
}
```

---

### `GET /contacts/pipeline-stats`

**Response `200`**
```json
{
  "success": true,
  "data": { "new": 142, "contacted": 89, "qualified": 34, "converted": 21, "lost": 8 }
}
```

---

### `GET /contacts/:id`

**Response `200`**
```json
{
  "success": true,
  "data": {
    "id": 101, "phone": "+15551234567", "name": "John Doe",
    "stage": "qualified", "tags": ["vip", "enterprise"],
    "created_at": "2026-01-15T10:00:00Z"
  }
}
```

**Errors:** `404` contact not found or belongs to another tenant

---

### `POST /contacts`

**Request Body**
```json
{
  "phone": "+15551234567",
  "name": "John Doe",
  "email": "john@doe.com",
  "stage": "new",
  "notes": "Met at conference"
}
```

**Response `201`** · **Errors:** `409` phone already exists for tenant · `422` validation

---

### `PATCH /contacts/:id`

**Request Body** (all optional)
```json
{ "name": "John Doe Jr.", "stage": "qualified", "notes": "Upgraded plan", "email": null }
```

**Response `200`** · **Errors:** `404` not found

---

### `DELETE /contacts/:id`

Soft-delete (sets `deleted_at`). **Response `200`**

---

### `POST /contacts/:id/tags`

**Request Body** `{ "tag": "vip" }` · **Response `200`**

---

### `DELETE /contacts/:id/tags/:tag`

**Response `200`**

---

### `GET /contacts/:contactId/calls`

All calls for a contact.

**Query:** `cursor`, `limit` (1–100, default 20)

**Response `200`** — see Calls Module for call object shape.

---

## Messages Module

> **Auth:** Bearer JWT

### `POST /messages/send`

**Request Body**
```json
{
  "contactId": 101,
  "whatsappAccountId": 1,
  "content": "Hello John! Your order is ready.",
  "mediaUrl": "https://cdn.example.com/invoice.pdf",
  "mediaType": "application/pdf"
}
```

**Response `201`**
```json
{
  "success": true,
  "message": "Message queued for sending",
  "data": { "messageId": 5001, "status": "pending", "queuedAt": "2026-03-27T10:00:00Z" }
}
```

**Errors:** `404` WhatsApp account not found or wrong tenant · `422` validation

---

### `GET /messages/inbox`

Last message per contact (inbox view).

**Query Parameters**

| Param | Type | Default |
|---|---|---|
| `cursor` | string | — |
| `limit` | 1–100 | 30 |
| `unreadOnly` | boolean | false |

**Response `200`**
```json
{
  "success": true,
  "data": [
    {
      "tenant_id": 1, "contact_id": 101,
      "contact_name": "John Doe", "contact_phone": "+15551234567",
      "contact_stage": "qualified",
      "last_message": "Hello John! Your order is ready.",
      "last_direction": "outbound", "last_status": "delivered",
      "is_read": true, "unread_count": 0,
      "last_message_at": "2026-03-27T10:00:00Z"
    }
  ],
  "meta": { "nextCursor": "eyJ...", "hasMore": false }
}
```

---

### `GET /messages/conversation/:contactId`

Full message thread for a contact (newest first).

**Query:** `cursor`, `limit` (1–100, default 50)

**Response `200`**
```json
{
  "success": true,
  "data": [
    {
      "id": 5001, "direction": "outbound", "content": "Hello John!",
      "status": "delivered", "is_read": true,
      "sent_at": "2026-03-27T10:00:00Z", "delivered_at": "2026-03-27T10:00:05Z"
    }
  ],
  "meta": { "nextCursor": null, "hasMore": false }
}
```

---

### `PUT /messages/conversation/:contactId/read`

Mark all inbound messages in a thread as read. **Response `200`**

---

## Campaigns Module

> **Auth:** Bearer JWT

### Templates

#### `GET /campaigns/templates`

**Query:** `status` (draft|approved|rejected|pending_review)

**Response `200`** — array of template objects

---

#### `POST /campaigns/templates`

**Request Body**
```json
{
  "name": "Order Confirmation",
  "content": "Hello {{name}}, your order {{order_id}} is confirmed!",
  "variables": ["name", "order_id"],
  "category": "utility"
}
```

**Response `201`**

---

#### `PATCH /campaigns/templates/:id`

Partial update. **Response `200`**

---

#### `DELETE /campaigns/templates/:id`

Fails with `409` if active campaigns reference this template. **Response `200`**

---

### Campaigns

#### `GET /campaigns`

**Query Parameters**

| Param | Type | Description |
|---|---|---|
| `status` | enum | Filter by status |
| `search` | string | Search by name |
| `cursor` | string | Pagination cursor |
| `limit` | 1–100 | Default 30 |

**Response `200`** — paginated campaigns with template and WhatsApp account embedded

---

#### `GET /campaigns/:id`

**Response `200`** — full campaign with template and account details

---

#### `GET /campaigns/:id/recipients`

**Query:** `page`, `limit` (default 50), `status` (pending|sent|delivered|read|failed|opted_out)

**Response `200`**
```json
{
  "success": true,
  "data": [
    { "id": 1, "contact": { "id": 101, "name": "John", "phone": "+1555..." }, "status": "delivered", "delivered_at": "..." }
  ],
  "meta": { "total": 1420, "page": 1, "limit": 50, "totalPages": 29 }
}
```

---

#### `POST /campaigns`

**Auth:** owner or admin only

**Request Body**
```json
{
  "name": "March Promo",
  "templateId": 5,
  "whatsappAccountId": 1,
  "scheduledAt": "2026-04-01T10:00:00Z",
  "contactIds": [101, 102, 103],
  "filters": { "stage": "qualified", "tags": ["vip"] }
}
```

> Use either `contactIds` OR `filters`, not both.

**Response `201`**
```json
{
  "success": true,
  "data": { "id": 42, "name": "March Promo", "status": "scheduled", "recipientCount": 1420 }
}
```

---

#### `POST /campaigns/:id/send`

Immediately dispatch a draft or scheduled campaign. **Auth:** owner or admin

**Response `200`** `{ "data": { "campaignId": 42, "status": "queued" } }`

**Errors:** `409` invalid state · `400` no recipients

---

#### `POST /campaigns/:id/cancel`

**Auth:** owner or admin · **Response `200`** · **Errors:** `409` already completed/failed

---

## Calls / IVR Module

> **Auth:** Bearer JWT · All calls scoped to authenticated tenant.

### `GET /calls`

**Query Parameters**

| Param | Type | Description |
|---|---|---|
| `status` | enum | initiated, ringing, in-progress, completed, busy, failed, no-answer, cancelled |
| `direction` | inbound\|outbound | Filter direction |
| `from_date` | ISO 8601 | Range start (queries partitioned table correctly) |
| `to_date` | ISO 8601 | Range end |
| `contact_id` | integer | Filter to calls for a contact |
| `cursor` | string | Pagination cursor |
| `limit` | 1–100 | Default 30 |

**Response `200`**
```json
{
  "success": true,
  "data": [
    {
      "id": "CA1234567890abcdef",
      "direction": "inbound",
      "status": "completed",
      "from_number": "+15559876543",
      "to_number": "+15551234567",
      "started_at": "2026-03-27T09:00:00Z",
      "answered_at": "2026-03-27T09:00:05Z",
      "ended_at": "2026-03-27T09:04:32Z",
      "duration_seconds": 267,
      "cost": 0.0267,
      "cost_currency": "USD",
      "ivr_flow_id": "flow_support_v2"
    }
  ],
  "meta": { "nextCursor": "eyJ...", "hasMore": true }
}
```

---

### `GET /calls/stats`

Aggregated statistics for a date range.

**Query Parameters**

| Param | Type | Default |
|---|---|---|
| `from_date` | ISO 8601 | 30 days ago |
| `to_date` | ISO 8601 | now |
| `group_by` | day\|week\|month | — |

**Response `200`**
```json
{
  "success": true,
  "data": {
    "total": 1420,
    "completed": 1280,
    "failed": 42,
    "noAnswer": 65,
    "busy": 33,
    "inbound": 890,
    "outbound": 530,
    "totalDurationSeconds": 341760,
    "avgDurationSeconds": 267,
    "totalCost": 142.50,
    "avgMosScore": 4.2,
    "avgTotalLatencyMs": 540
  }
}
```

---

### `GET /calls/:id`

**Response `200`** — full call object (see list example above)

**Errors:** `404` call not found or belongs to another tenant

---

### `GET /calls/:id/metrics`

AI voice quality metrics.

**Response `200`**
```json
{
  "success": true,
  "data": {
    "id": 1,
    "call_id": "CA1234567890abcdef",
    "stt_latency_ms": 120,
    "llm_latency_ms": 340,
    "tts_latency_ms": 80,
    "total_latency_ms": 540,
    "packet_loss": 0.005,
    "jitter_ms": 4.2,
    "bitrate_kbps": 64,
    "mos_score": 4.2,
    "recorded_at": "2026-03-27T09:00:30Z"
  }
}
```

Returns `null` data if no metrics recorded for this call.

---

### `GET /calls/:id/transcripts`

Paginated transcript segments ordered by audio position.

**Query Parameters**

| Param | Type | Description |
|---|---|---|
| `speaker` | agent\|customer\|system | Filter by speaker |
| `cursor` | string | Pagination |
| `limit` | 1–200 | Default 50 |

**Response `200`**
```json
{
  "success": true,
  "data": [
    {
      "id": 501, "speaker": "customer",
      "content": "Hello, I need help with my account.",
      "confidence": 0.97,
      "word_count": 8,
      "segment_start_ms": 0,
      "segment_end_ms": 2340
    },
    {
      "id": 502, "speaker": "agent",
      "content": "Of course! I'd be happy to help. Can I get your account number?",
      "confidence": 0.99,
      "segment_start_ms": 2800,
      "segment_end_ms": 5100
    }
  ],
  "meta": { "nextCursor": "eyJ...", "hasMore": true }
}
```

---

### `GET /calls/:id/events`

All lifecycle events for a call (not paginated — usually <50 events per call).

**Response `200`**
```json
{
  "success": true,
  "data": [
    { "event_type": "call_initiated", "metadata": { "ivr_flow": "support_v2" }, "created_at": "2026-03-27T09:00:00Z" },
    { "event_type": "ringing",        "metadata": {},                            "created_at": "2026-03-27T09:00:01Z" },
    { "event_type": "answered",       "metadata": { "answered_by": "ivr" },     "created_at": "2026-03-27T09:00:05Z" },
    { "event_type": "ivr_menu",       "metadata": { "selection": "2" },         "created_at": "2026-03-27T09:00:12Z" },
    { "event_type": "hangup",         "metadata": { "hangup_cause": "normal" }, "created_at": "2026-03-27T09:04:32Z" }
  ]
}
```

---

### `GET /calls/:id/recording`

Recording metadata and URL. Returns `404` if deleted or not found.

**Response `200`**
```json
{
  "success": true,
  "data": {
    "id": 1,
    "call_id": "CA1234567890abcdef",
    "recording_url": "https://storage.example.com/recordings/CA1234.mp3",
    "duration_seconds": 267,
    "size_bytes": 2139136,
    "is_deleted": false,
    "created_at": "2026-03-27T09:05:00Z"
  }
}
```

---

## WhatsApp Accounts Module

> **Auth:** Bearer JWT

### `GET /whatsapp-accounts`

**Response `200`** — array of accounts (api_token_encrypted never returned)
```json
{
  "success": true,
  "data": [
    {
      "id": 1, "phone_number": "+15551234567", "display_name": "Acme Support",
      "provider": "meta", "status": "active",
      "daily_message_limit": 1000, "last_sent_at": "2026-03-27T08:00:00Z"
    }
  ]
}
```

---

### `POST /whatsapp-accounts`

**Auth:** owner or admin

**Request Body**
```json
{
  "phoneNumber": "+15551234567",
  "displayName": "Acme Support",
  "apiToken": "EAAGm...",
  "provider": "meta",
  "dailyMessageLimit": 1000
}
```

**Response `201`** · **Errors:** `409` phone already connected

---

### `PATCH /whatsapp-accounts/:id`

**Auth:** owner or admin · **Body** (all optional):
```json
{ "displayName": "Acme Sales", "dailyMessageLimit": 5000, "status": "inactive", "apiToken": "newToken..." }
```

---

### `DELETE /whatsapp-accounts/:id`

**Auth:** owner only · Sets status to `disconnected`. **Response `200`**

---

## API Keys Module

> **Auth:** Bearer JWT

### `GET /api-keys`

**Response `200`** — array of keys (key_hash never returned)
```json
{
  "success": true,
  "data": [
    {
      "id": 1, "name": "CRM Integration", "key_prefix": "sk_live_abc1",
      "scopes": ["contacts:read", "messages:write"],
      "is_active": true, "expires_at": "2027-01-01T00:00:00Z",
      "last_used_at": "2026-03-27T09:00:00Z"
    }
  ]
}
```

---

### `POST /api-keys`

**Auth:** owner or admin

**Request Body**
```json
{
  "name": "CRM Integration",
  "scopes": ["contacts:read", "messages:write"],
  "expiresAt": "2027-01-01T00:00:00Z"
}
```

**Available Scopes:**
`*` (all) · `contacts:read` · `contacts:write` · `messages:read` · `messages:write` · `campaigns:read` · `campaigns:write` · `calls:read` · `whatsapp:read` · `whatsapp:write` · `settings:read` · `settings:write`

**Response `201`**
```json
{
  "success": true,
  "message": "API key created — save the raw_key now, it will not be shown again",
  "data": {
    "id": 1, "name": "CRM Integration", "key_prefix": "sk_live_abc1",
    "raw_key": "sk_live_abc1234",
    "scopes": ["contacts:read", "messages:write"], "is_active": true
  }
}
```

---

### `PATCH /api-keys/:id`

Update name, scopes, or expiry. **Response `200`**

---

### `DELETE /api-keys/:id`

Revoke key (soft-delete). **Response `200`**

---

## Tenant Settings Module

> **Auth:** Bearer JWT

### `GET /settings`

**Response `200`**
```json
{
  "success": true,
  "data": {
    "tenant_id": 1,
    "max_users": 10,
    "max_contacts": 5000,
    "max_whatsapp_accounts": 3,
    "max_campaigns": 50,
    "timezone": "America/New_York",
    "webhook_url": "https://myapp.com/webhooks",
    "updated_at": "2026-03-01T00:00:00Z"
  }
}
```

---

### `PATCH /settings`

**Auth:** owner or admin · **Body** (all optional):
```json
{
  "timezone": "Europe/London",
  "webhook_url": "https://myapp.com/hooks",
  "max_contacts": 10000
}
```

---

### `POST /settings/webhook-secret`

**Auth:** owner only · Rotate the HMAC secret used to sign outgoing webhooks.

**Response `200`**
```json
{
  "success": true,
  "message": "Webhook secret rotated — save this now, it will not be shown again",
  "data": { "webhook_secret": "whsec_abc123..." }
}
```

---

## Webhooks

> **No JWT required** — signature-verified instead.

### `GET /webhooks/meta`

Meta webhook challenge verification. Handled automatically; used when configuring the webhook URL in Meta Developer Console.

**Query:** `hub.mode`, `hub.verify_token`, `hub.challenge`

**Response `200`** — echoes `hub.challenge` value

---

### `POST /webhooks/meta`

**Header:** `X-Hub-Signature-256: sha256=<hex>`

Receives WhatsApp Business API events. Always returns `200` immediately to prevent Meta retries. Processing happens asynchronously via queue.

**Response `200`** `{ "received": true }`

---

### `POST /webhooks/twilio`

**Header:** `X-Twilio-Signature: <base64>`

Receives Twilio status callbacks. Returns TwiML.

**Response `200`** `<Response/>`

---

## Admin Module

> **Auth:** Bearer JWT where user has `user_metadata.is_super_admin = true`
>
> All endpoints are audit-logged to `admin_audit_log`.

### Stats

#### `GET /admin/stats`

**Response `200`**
```json
{
  "success": true,
  "data": {
    "activeTenants": 142,
    "activeUsers": 891,
    "totalContacts": 2840000,
    "totalMessages": 18500000,
    "totalCampaigns": 4200
  }
}
```

---

### Users

#### `GET /admin/users`

**Query:** `page`, `limit`, `tenant_id`

#### `GET /admin/users/:id`

#### `PUT /admin/users/:id/role`

**Body:** `{ "role": "admin" }` — valid: `owner|admin|member|viewer`

#### `POST /admin/users/:id/deactivate`

#### `DELETE /admin/users/:id`

Permanently removes from Supabase Auth.

---

### Tenants

#### `GET /admin/tenants`

**Query:** `page`, `limit`, `status` (active|suspended|deleted), `plan`

#### `GET /admin/tenants/:id`

#### `PATCH /admin/tenants/:id`

**Body:** `{ "name": "New Name", "plan": "pro" }`

#### `POST /admin/tenants/:id/suspend`

#### `POST /admin/tenants/:id/activate`

#### `DELETE /admin/tenants/:id`

Soft-delete (sets `status = 'deleted'`).

#### `GET /admin/tenants/:id/settings`

#### `PUT /admin/tenants/:id/settings`

---

### Contacts (Cross-Tenant)

#### `GET /admin/contacts`

**Query:** `page`, `limit`, `tenant_id`, `stage`, `search`

#### `POST /admin/contacts/import`

**Body:**
```json
{
  "tenantId": 1,
  "contacts": [
    { "phone": "+15551234567", "name": "John Doe", "email": "john@doe.com" }
  ]
}
```
Max 10,000 contacts per request.

#### `DELETE /admin/contacts/all`

**Query:** `tenant_id` **(required)** — deletes all contacts for that tenant only.

#### `DELETE /admin/contacts/:id/hard`

Permanent hard-delete. **Query:** `tenant_id` optional safety filter.

---

### Messages (Cross-Tenant)

#### `GET /admin/messages`

**Query:** `page`, `limit`, `tenant_id`, `direction`, `status`

#### `DELETE /admin/messages/:id`

**Query:** `sent_at` (ISO 8601) — required for correct composite PK match on partitioned table.

---

### Campaigns (Cross-Tenant)

#### `GET /admin/campaigns`

**Query:** `page`, `limit`, `tenant_id`, `status`

#### `DELETE /admin/campaigns/:id`

Also deletes all recipients.

#### `POST /admin/campaigns/:id/force-send`

**Body:** `{ "tenantId": 1 }` — resets to draft and dispatches.

#### `POST /admin/campaigns/:id/retry`

**Body:** `{ "tenantId": 1 }` — resets failed recipients to pending and re-dispatches.

---

### Calls (Cross-Tenant)

#### `GET /admin/calls`

**Query:** `page`, `limit`, `tenant_id`, `status`, `direction`

---

### API Keys (Cross-Tenant)

#### `GET /admin/api-keys`

**Query:** `page`, `limit`, `tenant_id`, `is_active` (true|false)

#### `POST /admin/api-keys`

**Body:**
```json
{ "tenantId": 1, "name": "Admin Key", "scopes": ["*"], "expiresAt": "2027-01-01T00:00:00Z" }
```

#### `DELETE /admin/api-keys/:id`

Revokes the key.

---

### Logs

#### `GET /admin/logs`

Admin audit log.

**Query:** `page`, `limit`, `user_id`, `tenant_id`, `action`

#### `GET /admin/api-logs`

API request logs.

**Query:** `page`, `limit`, `tenant_id`, `status_code`

#### `GET /admin/login-attempts`

**Query:** `page`, `limit`, `email`, `tenant_id`, `success` (true|false)

---

### Dynamic DB (Escape Hatch)

> Accessible tables: `tenants`, `tenant_settings`, `user_profiles`, `contacts`, `contact_tags`, `messages`, `campaigns`, `campaign_recipients`, `message_templates`, `whatsapp_accounts`, `api_keys`, `login_attempts`, `calls`, `call_metrics`, `call_recordings`

#### `GET /admin/db/tables`

Returns list of accessible tables.

#### `GET /admin/db/:table`

**Query:** `page`, `limit`, `tenant_id`

#### `POST /admin/db/:table`

**Body:** Row object. `created_at`, `updated_at` are stripped.

#### `PUT /admin/db/:table/:id`

**Body:** Partial row. `id`, `tenant_id`, `created_at` are stripped for safety.

#### `DELETE /admin/db/:table/:id`

#### `DELETE /admin/db/truncate/:table`

Protected tables (`tenants`, `user_profiles`, `api_keys`) cannot be truncated.

#### `DELETE /admin/db/reset`

**Body:** `{ "confirm": "RESET_CONFIRMED" }` — truncates `campaign_recipients`, `campaigns`, `messages`, `contacts`, `contact_tags`.

---

## Pagination

All list endpoints use **cursor-based pagination** (except admin endpoints which use offset).

### Cursor Pagination Response
```json
{
  "data": [...],
  "meta": {
    "nextCursor": "eyJpZCI6MTAxLCJ0cyI6IjIwMjYtMDMtMjdUMTA6MDA6MDBaIn0=",
    "hasMore": true
  }
}
```

Pass `nextCursor` value as `cursor` query param in the next request.

### Offset Pagination Response (admin)
```json
{
  "data": [...],
  "meta": { "total": 1420, "page": 1, "limit": 20, "totalPages": 71 }
}
```

---

## Using API Keys

API keys authenticate external integrations (no JWT needed).

```bash
curl https://api.example.com/api/v1/contacts \
  -H "X-API-Key: sk_live_abc1234..."
```

The key must have the appropriate scope for the endpoint being called. A key with scope `*` has full access.

---

## Notes on Partitioned Tables

The database uses time-based table partitioning for `calls`, `messages`, `call_events`, `call_transcripts`, and `api_logs`. All queries go to the **parent table** — Postgres automatically routes to the correct partition based on the date column. This is transparent to the API consumer. Date range filters (`from_date`, `to_date`) dramatically improve query performance by enabling partition pruning.
