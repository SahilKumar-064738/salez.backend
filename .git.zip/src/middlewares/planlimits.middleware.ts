// src/middlewares/planLimits.middleware.ts
// ─────────────────────────────────────────────────────────────────────────────
// Factory functions that create Express middlewares for plan-limit enforcement.
// Use these as route-level guards — they run AFTER authMiddleware +
// tenantContextMiddleware so req.user.tenantId is guaranteed to be set.
//
// USAGE EXAMPLE (in routes/index.ts):
//
//   import { enforceLimit, enforceFeature } from '../middlewares/planLimits.middleware';
//
//   contactsRouter.post('/',
//     enforceLimit('contacts', 'max_contacts'),   // ← guard
//     validate(CreateContactSchema),
//     (req, res, next) => contactsController.create(req, res, next)
//   );
//
//   automationRouter.use(enforceFeature('automation'));  // ← whole sub-router
// ─────────────────────────────────────────────────────────────────────────────

import type { Request, Response, NextFunction } from 'express';
import { plansService, LimitKey, FeatureKey } from '../services/plans.service';
import { AuthenticatedRequest } from '../types';
import { logger } from '../utils/logger';

// ── resolveCount function registry ────────────────────────────────────────────
// Maps a resource name to the function that counts current usage.

type CountFn = (tenantId: number) => Promise<number>;

const COUNT_FNS: Record<string, CountFn> = {
  contacts:          (id) => plansService.countContacts(id),
  users:             (id) => plansService.countUsers(id),
  whatsapp_accounts: (id) => plansService.countWhatsAppAccounts(id),
  campaigns:         (id) => plansService.countCampaigns(id),
  api_keys:          (id) => plansService.countApiKeys(id),
  message_templates: (id) => plansService.countMessageTemplates(id),
};

// ── enforceLimit ──────────────────────────────────────────────────────────────

/**
 * Middleware factory: counts the resource and throws 429 if at/over limit.
 *
 * @param resource    - key in COUNT_FNS registry (e.g. 'contacts')
 * @param limitKey    - column name in PlanLimits (e.g. 'max_contacts')
 * @param label       - human-readable name shown in the error message
 */
export function enforceLimit(
  resource: string,
  limitKey: LimitKey,
  label?: string,
) {
  const resourceLabel = label ?? resource.replace(/_/g, ' ');
  const countFn = COUNT_FNS[resource];

  if (!countFn) {
    throw new Error(
      `enforceLimit: unknown resource "${resource}". ` +
      `Register a count function in COUNT_FNS.`
    );
  }

  return async function planLimitGuard(
    req: Request,
    _res: Response,
    next: NextFunction,
  ): Promise<void> {
    const { user } = req as AuthenticatedRequest;

    try {
      const currentCount = await countFn(user.tenantId);
      await plansService.assertWithinLimit(
        user.tenantId,
        limitKey,
        currentCount,
        resourceLabel,
      );
      next();
    } catch (err) {
      logger.warn(
        { tenantId: user.tenantId, resource, limitKey },
        'Plan limit exceeded'
      );
      next(err);
    }
  };
}

// ── enforceFeature ────────────────────────────────────────────────────────────

/**
 * Middleware factory: blocks the request if a feature flag is not enabled
 * on this tenant's plan.
 *
 * @param feature - feature key (e.g. 'automation', 'ivr', 'call_recording')
 */
export function enforceFeature(feature: FeatureKey) {
  return async function featureGuard(
    req: Request,
    _res: Response,
    next: NextFunction,
  ): Promise<void> {
    const { user } = req as AuthenticatedRequest;

    try {
      await plansService.assertFeatureEnabled(user.tenantId, feature);
      next();
    } catch (err) {
      logger.warn(
        { tenantId: user.tenantId, feature },
        'Feature not available on current plan'
      );
      next(err);
    }
  };
}

// ── enforceCampaignRecipientLimit ─────────────────────────────────────────────

/**
 * Special-purpose guard for campaign creation.
 * Reads 'contactIds.length' or counts contacts from filter query and
 * compares against max_campaign_recipients.
 */
export async function enforceCampaignRecipientLimit(
  req: Request,
  _res: Response,
  next: NextFunction,
): Promise<void> {
  const { user } = req as AuthenticatedRequest;
  const { contactIds } = req.body as { contactIds?: number[] };

  // If explicit contactIds provided, count them directly
  if (Array.isArray(contactIds)) {
    try {
      await plansService.assertWithinLimit(
        user.tenantId,
        'max_campaign_recipients',
        contactIds.length,
        'Campaign recipients',
      );
    } catch (err) {
      return next(err);
    }
  }

  // If using filters (dynamic audience), we skip count here and enforce
  // at the time of actual sending in the worker (deferred enforcement).
  next();
}