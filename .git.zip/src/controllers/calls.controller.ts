import { Request, Response, NextFunction } from 'express';
import { callsRepository } from '../repositories/calls.repository';
import { AuthenticatedRequest } from '../types';
import { validate } from '../utils/validation';
import * as R from '../utils/response';
import { z } from 'zod';

// ── SCHEMAS ───────────────────────────────────────────────────────────────────

const CallsListSchema = z.object({
  cursor: z.string().optional(),
  limit: z.coerce.number().int().min(1).max(100).default(30),
  status: z.enum(['initiated', 'ringing', 'in-progress', 'completed', 'busy', 'failed', 'no-answer', 'cancelled']).optional(),
  direction: z.enum(['inbound', 'outbound']).optional(),
  from_date: z.string().datetime({ offset: true }).optional(),
  to_date: z.string().datetime({ offset: true }).optional(),
  contact_id: z.coerce.number().int().positive().optional(),
  assigned_user_id: z.string().uuid().optional(),
});

const TranscriptsQuerySchema = z.object({
  cursor: z.string().optional(),
  limit: z.coerce.number().int().min(1).max(200).default(50),
  speaker: z.enum(['agent', 'customer', 'system']).optional(),
});

const StatsQuerySchema = z.object({
  from_date: z.string().datetime({ offset: true }).default(
    () => new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString()
  ),
  to_date: z.string().datetime({ offset: true }).default(() => new Date().toISOString()),
  group_by: z.enum(['day', 'week', 'month']).optional(),
});

const ContactCallsSchema = z.object({
  cursor: z.string().optional(),
  limit: z.coerce.number().int().min(1).max(100).default(20),
});

// ── CONTROLLER ────────────────────────────────────────────────────────────────

export class CallsController {
  /**
   * GET /calls
   * List calls with cursor pagination and rich filters.
   */
  async list(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const { user } = req as AuthenticatedRequest;
      const q = CallsListSchema.parse(req.query);

      const result = await callsRepository.list(user.tenantId, {
        cursor: q.cursor,
        limit: q.limit,
        status: q.status,
        direction: q.direction,
        fromDate: q.from_date,
        toDate: q.to_date,
        contactId: q.contact_id,
        assignedUserId: q.assigned_user_id,
      });

      R.cursor(res, result.data, result.nextCursor, result.hasMore);
    } catch (e) { next(e); }
  }

  /**
   * GET /calls/stats
   * Aggregated call statistics (total, completed, failed, duration, cost, quality).
   */
  async getStats(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const { user } = req as AuthenticatedRequest;
      const q = StatsQuerySchema.parse(req.query);

      const stats = await callsRepository.getCallStats(
        user.tenantId,
        q.from_date,
        q.to_date,
        q.group_by
      );

      R.success(res, stats);
    } catch (e) { next(e); }
  }

  /**
   * GET /calls/:id
   * Get a single call by ID with tenant isolation.
   */
  async getById(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const { user } = req as AuthenticatedRequest;
      const call = await callsRepository.findById(user.tenantId, req.params.id);
      R.success(res, call);
    } catch (e) { next(e); }
  }

  /**
   * GET /calls/:id/metrics
   * Quality metrics: STT/LLM/TTS latency, packet loss, jitter, MOS score.
   */
  async getMetrics(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const { user } = req as AuthenticatedRequest;
      const metrics = await callsRepository.getMetrics(user.tenantId, req.params.id);
      R.success(res, metrics);
    } catch (e) { next(e); }
  }

  /**
   * GET /calls/:id/transcripts
   * Paginated transcript segments ordered by audio position.
   * Optionally filter by speaker (agent | customer | system).
   */
  async getTranscripts(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const { user } = req as AuthenticatedRequest;
      const q = TranscriptsQuerySchema.parse(req.query);

      const result = await callsRepository.getTranscripts(
        user.tenantId,
        req.params.id,
        { limit: q.limit, cursor: q.cursor, speaker: q.speaker }
      );

      R.cursor(res, result.data, result.nextCursor, result.hasMore);
    } catch (e) { next(e); }
  }

  /**
   * GET /calls/:id/events
   * All lifecycle events for a call, chronological order.
   * Examples: call_initiated, ringing, answered, ivr_menu_selected, hangup.
   */
  async getEvents(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const { user } = req as AuthenticatedRequest;
      const events = await callsRepository.getEvents(user.tenantId, req.params.id);
      R.success(res, events);
    } catch (e) { next(e); }
  }

  /**
   * GET /calls/:id/recording
   * Recording URL and metadata. Returns 404 if recording is deleted or not found.
   */
  async getRecording(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const { user } = req as AuthenticatedRequest;
      const recording = await callsRepository.getRecording(user.tenantId, req.params.id);
      R.success(res, recording);
    } catch (e) { next(e); }
  }

  /**
   * GET /contacts/:contactId/calls
   * All calls for a specific contact (used by contact detail view).
   * Mounted on the contacts router.
   */
  async getContactCalls(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const { user } = req as AuthenticatedRequest;
      const contactId = parseInt(req.params.contactId, 10);
      const q = ContactCallsSchema.parse(req.query);

      const result = await callsRepository.getContactCalls(user.tenantId, contactId, q);
      R.cursor(res, result.data, result.nextCursor, result.hasMore);
    } catch (e) { next(e); }
  }
}

export const callsController = new CallsController();
