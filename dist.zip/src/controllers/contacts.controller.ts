import { Request, Response, NextFunction } from 'express';
import { contactsRepository } from '../repositories/contacts.repository';
import { AuthenticatedRequest, AppError } from '../types';
import * as R from '../utils/response';
import {
  CreateContactSchema,
  UpdateContactSchema,
  ContactsQuerySchema,
  TagSchema,
  BulkCreateContactSchema,
} from '../utils/validation';

export class ContactsController {
  async list(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const { user } = req as AuthenticatedRequest;
      const q = ContactsQuerySchema.parse(req.query);
      const result = await contactsRepository.list(user.tenantId, {
        cursor: q.cursor,
        limit: q.limit,
        stage: q.stage,
        search: q.search,
        tag: q.tag,
      });
      R.cursor(res, result.data, result.nextCursor, result.hasMore);
    } catch (e) {
      next(e);
    }
  }

  async getPipelineStats(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const { user } = req as AuthenticatedRequest;
      const stats = await contactsRepository.getPipelineStats(user.tenantId);
      R.success(res, stats);
    } catch (e) {
      next(e);
    }
  }

  async getById(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const { user } = req as AuthenticatedRequest;
      const id = parseInt(req.params.id, 10);
      if (isNaN(id)) throw new AppError('Invalid contact ID', 400, 'INVALID_PARAM');
      const contact = await contactsRepository.findById(user.tenantId, id);
      R.success(res, contact);
    } catch (e) {
      next(e);
    }
  }

  async create(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const { user } = req as AuthenticatedRequest;
      const body = CreateContactSchema.parse(req.body);
      const contact = await contactsRepository.create(user.tenantId, body);
      R.created(res, contact, 'Contact created');
    } catch (e) {
      next(e);
    }
  }

  async update(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const { user } = req as AuthenticatedRequest;
      const id = parseInt(req.params.id, 10);
      if (isNaN(id)) throw new AppError('Invalid contact ID', 400, 'INVALID_PARAM');
      const body = UpdateContactSchema.parse(req.body);
      const contact = await contactsRepository.update(user.tenantId, id, body);
      R.success(res, contact, 'Contact updated');
    } catch (e) {
      next(e);
    }
  }

  async delete(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const { user } = req as AuthenticatedRequest;
      const id = parseInt(req.params.id, 10);
      if (isNaN(id)) throw new AppError('Invalid contact ID', 400, 'INVALID_PARAM');
      await contactsRepository.delete(user.tenantId, id);
      R.success(res, null, 'Contact deleted');
    } catch (e) {
      next(e);
    }
  }

  async addTag(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const { user } = req as AuthenticatedRequest;
      const id = parseInt(req.params.id, 10);
      if (isNaN(id)) throw new AppError('Invalid contact ID', 400, 'INVALID_PARAM');
      const { tag } = TagSchema.parse(req.body);
      await contactsRepository.addTag(user.tenantId, id, tag);
      R.success(res, null, 'Tag added');
    } catch (e) {
      next(e);
    }
  }

  async removeTag(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const { user } = req as AuthenticatedRequest;
      const id = parseInt(req.params.id, 10);
      if (isNaN(id)) throw new AppError('Invalid contact ID', 400, 'INVALID_PARAM');
      const tag = req.params.tag;
      if (!tag) throw new AppError('Tag is required', 400, 'INVALID_PARAM');
      await contactsRepository.removeTag(user.tenantId, id, tag);
      R.success(res, null, 'Tag removed');
    } catch (e) {
      next(e);
    }
  }

  /**
   * POST /contacts/bulk
   * Body: { contacts: [{ phone, name?, email?, stage?, notes? }] }
   * - Validates each entry with the same schema as single create
   * - Max 500 per batch (enforced in schema)
   * - Plan limit is checked BEFORE insert via enforceLimit middleware
   */
  async bulkCreate(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const { user } = req as AuthenticatedRequest;
      const { contacts } = BulkCreateContactSchema.parse(req.body);
      const result = await contactsRepository.bulkCreate(user.tenantId, contacts);
      R.created(res, result, `${result.length} contacts created`);
    } catch (e) {
      next(e);
    }
  }
}

export const contactsController = new ContactsController();